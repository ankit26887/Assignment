package com.wipro.assignment.controller;

import com.wipro.assignment.model.Request;
import com.wipro.assignment.model.Response;
import com.wipro.assignment.service.BiggestNumber;
import com.wipro.assignment.service.FindDuplicates;
import com.wipro.assignment.service.RemoveWhiteSpaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.function.ServerRequest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@RestController
public class TaskController {

    @Autowired
    BiggestNumber biggestNumber;

    @Autowired
    FindDuplicates findDuplicates;

    @Autowired
    RemoveWhiteSpaces removeWhiteSpaces;
   /* @Autowired
    InsertRecords insertRecords;*/


    @PostMapping(value="/incoming")
    public ResponseBody performOperations(@RequestBody Request request){

        if(validateRequest(request)){
            HashMap<Character, Integer> duplicates = findDuplicates.findDuplicates(request.getFindDuplicates());
            String stringWithoutSpace = removeWhiteSpaces.removewhiteSpaces(request.getWhiteSpacesGalore());
            Integer biggestNumber = this.biggestNumber.findBiggestNumber(request.getNumbersMeetNumbers());

           //TODO - Inserting the records in MongoDB


           /* insertRecords.save(response);*/
       }
        return null;
    }


    public boolean validateRequest (Request request){
        if(!Pattern.matches("\\d*",request.getRequestId())){
            return false;
        }
        if(!Pattern.matches("\\w*",request.getFindDuplicates())){
      return false;
        }
        String [] sentence = request.getWhiteSpacesGalore().split(" ");
        for(String word : sentence)
        if(!Pattern.matches("\\w*",word)){
            return false;
        }


        for(Integer numbers : request.getNumbersMeetNumbers()){
            if(!Pattern.matches("\\d*",numbers.toString())){
                return false;
            }
        }


            if(!Pattern.matches("true|TRUE|false|FALSE|True|False",request.getValidateMeOnlyIActuallyShouldBeABoolean().toString())){
                return  false;
            }
        return true;
    }

}
