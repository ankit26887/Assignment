package com.wipro.assignment.model;


import java.util.Map;

public class Response {

    private String id;
    private  Map<Character,Integer> findDuplicates;
    private  String whiteSpacesGalore;
    private   Integer numbersMeetNumbers;

    public Map<Character,Integer> getFindDuplicates() {
        return findDuplicates;
    }

    public void setFindDuplicates(Map<Character,Integer> findDuplicates) {
        this.findDuplicates = findDuplicates;
    }

    public String getWhiteSpacesGalore() {
        return whiteSpacesGalore;
    }

    public void setWhiteSpacesGalore(String whiteSpacesGalore) {
        this.whiteSpacesGalore = whiteSpacesGalore;
    }

    public Integer getNumbersMeetNumbers() {
        return numbersMeetNumbers;
    }

    public void setNumbersMeetNumbers(Integer numbersMeetNumbers) {
        this.numbersMeetNumbers = numbersMeetNumbers;
    }
}
