package com.wipro.assignment.service;

import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class FindDuplicates {
    public HashMap<Character, Integer> findDuplicates(String findDuplicates) {
        char[] chars = findDuplicates.toCharArray();
        HashMap<Character, Integer> characterCount = new HashMap<>();
        for(Character character : chars){

            if(characterCount.containsKey(character)) {
                int counter = characterCount.get(character);
                characterCount.put(character, ++counter);
            } else {
                characterCount.put(character, 1);
            }
        }

        return characterCount;
    }
}
