
//TODO
package com.wipro.assignment.repository;

import com.wipro.assignment.model.Response;
import org.springframework.stereotype.Repository;

/*@Repository
public interface TaskRepository extends MongoRepository<Response, String> {

}*/

