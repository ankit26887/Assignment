package com.wipro.assignment.service;

import org.springframework.stereotype.Service;

@Service
public class RemoveWhiteSpaces {
    public String removewhiteSpaces(String whiteSpacesGalore) {

        String [] strings = whiteSpacesGalore.split(" ");
        StringBuilder stringWithoutSpace = new StringBuilder();
        for(int index = 0; index<strings.length;index++){
            if(!strings[index].equals(" ")){
                stringWithoutSpace.append(strings[index]);
            }
        }
        return  stringWithoutSpace.toString();
    }
}
