package com.wipro.assignment.service;

import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class BiggestNumber {
    public Integer findBiggestNumber(List<Integer> numbersMeetNumbers) {
       return Collections.max(numbersMeetNumbers);
    }
}
