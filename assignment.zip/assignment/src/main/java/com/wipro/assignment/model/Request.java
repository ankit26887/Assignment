package com.wipro.assignment.model;


import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;


public class Request {
    public String requestId;
    public String findDuplicates;
    public String whiteSpacesGalore;

    public Boolean getValidateMeOnlyIActuallyShouldBeABoolean() {
        return validateMeOnlyIActuallyShouldBeABoolean;
    }

    public void setValidateMeOnlyIActuallyShouldBeABoolean(Boolean validateMeOnlyIActuallyShouldBeABoolean) {
        this.validateMeOnlyIActuallyShouldBeABoolean = validateMeOnlyIActuallyShouldBeABoolean;
    }

    public Boolean validateMeOnlyIActuallyShouldBeABoolean;
    public List<Integer> numbersMeetNumbers;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getFindDuplicates() {
        return findDuplicates;
    }

    public void setFindDuplicates(String findDuplicates) {
        this.findDuplicates = findDuplicates;
    }

    public String getWhiteSpacesGalore() {
        return whiteSpacesGalore;
    }

    public void setWhiteSpacesGalore(String whiteSpacesGalore) {
        this.whiteSpacesGalore = whiteSpacesGalore;
    }



    public List<Integer> getNumbersMeetNumbers() {
        return numbersMeetNumbers;
    }

    public void setNumbersMeetNumbers(List<Integer> numbersMeetNumbers) {
        this.numbersMeetNumbers = numbersMeetNumbers;
    }
}
