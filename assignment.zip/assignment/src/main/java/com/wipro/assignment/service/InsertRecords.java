//TODO

/*
package com.wipro.assignment.service;

import com.wipro.assignment.model.Response;
import com.wipro.assignment.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InsertRecords {

    @Autowired
    TaskRepository taskRepository;

    public void save(Response response){
        taskRepository.save(response);
    }
}
*/
