package com.wipro.assignment.service;

import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class RemoveWhiteSpacesTest {


    @Test
    public void testRemoveWhiteSpaces(){
        String input = "Hello This is a test string";
        RemoveWhiteSpaces removeWhiteSpaces = new RemoveWhiteSpaces();
        String s = removeWhiteSpaces.removewhiteSpaces(input);

        Assertions.assertEquals("HelloThisisateststring",s);


    }
}
